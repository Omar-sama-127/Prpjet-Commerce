<?php
session_start();
define("URI", "http://localhost/proteinshop/protein/");

//replace the index.php in the url 
define('ROOT', str_replace('index.php', '', $_SERVER['SCRIPT_FILENAME']));

require_once(ROOT . 'app/Model.php');
require_once(ROOT . 'app/Controller.php');


//on recuperer les le "p" et on separe les parametres
$params = explode('/', $_GET['p']);

//si un carctere existe 
if ($params[0] != "") {
    //le nom du controlleur 
    $controller = ucfirst($params[0]);
    //si le deuxieme parametre existe 


    $action = isset($params[1]) ? $params[1] : 'index';




    //on appel le controlleur 
    require_once(ROOT . 'controllers/' . $controller . '.php');
    //on instancie le controlleur
    $controller = new $controller();
    //on appel la methode du controlleur (action) si elle existe
    if (method_exists($controller, $action)) {
        $controller->$action();
    } else {
        echo "cette page n'existe pas";
        http_response_code(404);
    }
} else {
    //si le controlleur n'existe pas en renvoi vers le controlleur Main qui a une methode index 
    require_once(ROOT . 'controllers/Articles.php');


    $controller = new Articles();

    $controller->index();
}
