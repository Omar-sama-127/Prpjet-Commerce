<?php

class Utilisateur extends Model
{

    public function __construct()
    {
        parent::__construct();
        $this->table = "Utilisateur";
    }

    public function getAllUsers()
    {
        $this->sql = "SELECT * FROM $this->table";
        return $this->getLines();
    }

    public function ajouter($data)
    {
        $this->sql = " INSERT INTO $this->table (nom,prenom,email,telephone,date_naissance,mot_de_passe,id_role)
        VALUES (:nom,:prenom,:email,:telephone,:date_naissance,:mot_de_passe,:id_role)";
        return  $this->getLines($data, null);
    }



    public function findByEmail($data)
    {
        $this->sql = "SELECT * FROM $this->table WHERE email = :email ";
        return $this->getLines($data, true);
    }
    public function modifierById($data)
    {
        $this->sql = "UPDATE $this->table set nom=:nom , prenom=:prenom, email=:email, telephone=:telephone, date_naissance=:date_naissance
                        WHERE id_utilisateur=:id_utilisateur";
        return $this->getLines($data, null);
    }
    public function supprimerUtilisateur($data)
    {
        $this->sql = "DELETE FROM $this->table WHERE id_utilisateur = :id_utilisateur ";
        return $this->getLines($data, null);
    }
}
