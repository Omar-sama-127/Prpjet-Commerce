<?php

class Article extends Model
{


    public function __construct()
    {
        parent::__construct();
        $this->table = "Article";
    }

    //we retrieve all the protein articls in the table
    public function getAll()
    {
        $this->sql = "SELECT a.*, GROUP_CONCAT(i.chemin_image) AS chemin_images from $this->table a LEFT JOIN Image i ON a.id_article = i.id_article GROUP BY a.id_article ";
        return $this->getLines();
    }

    public function getArticleById($data)
    {
        $this->sql = "SELECT a.*, GROUP_CONCAT(i.chemin_image) AS chemin_images from $this->table a LEFT JOIN Image i ON a.id_article = i.id_article WHERE a.id_article = :id_article GROUP BY a.id_article";
        return $this->getLines($data, true);
    }


    //ajouter un article a la base de donnee
    public function ajout($data)
    {
        $this->sql = "insert into $this->table (nom, prix, description, id_type, courte_description, quantite)
                        values (:nom, :prix, :description, :id_type, :courte_description, :quantite)";
        return $this->getLines($data, null);
    }

    public function modiferById($data)
    {
        $this->sql = "UPDATE $this->table SET nom=:nom, prix=:prix, description=:description, id_type=:id_type, courte_description=:courte_description, quantite=:quantite 
                        WHERE id_article=:id_article";
        return $this->getLines($data, null);
    }
    public function supprimerById($data)
    {
        $this->sql = "DELETE FROM  $this->table  
                        WHERE id_article=:id_article";
        return $this->getLines($data, null);
    }
}
