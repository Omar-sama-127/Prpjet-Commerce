<?php
class Image extends Model
{
    public function __construct()
    {
        parent::__construct();
        $this->table = "Image";
    }


    public function getAll()
    {
        $this->sql = "SELECT * FROM $this->table ";
        return $this->getLines();
    }

    public function getImageById($data)
    {
        $this->sql = "SELECT * FROM $this->table WHERE id_article = :id_article";
        return $this->getLines($data, true);
    }

    public function ajouter($data)
    {
        $this->sql = "INSERT INTO $this->table (id_article, chemin_image) VALUES (:id_article, :chemin_image)";
        return $this->getLines($data, null);
    }
    public function deleteByChemin($data)
    {
        $this->sql = "DELETE FROM $this->table WHERE chemin_image = :chemin_image";
        return $this->getLines($data, null);
    }
    public function supprimerByIdArticle($data)
    {
        $this->sql = "DELETE FROM $this->table WHERE id_article = :id_article";
        return $this->getLines($data, null);
    }
}
