<?php
class Panier extends Model
{
    public function __construct()
    {
        if (!isset($_SESSION["panier"])) {
            $_SESSION["panier"] = [];
        }
    }

    public function ajouter($id, $quantite)
    {
        $_SESSION["panier"][$id] = $quantite;
    }

    public function supprimer($id)
    {
        unset($_SESSION["panier"][$id]);
    }
    public function getAllPanier()
    {
        require_once(ROOT . "models/Article.php");
        $articles = [];

        foreach ($_SESSION["panier"] as $id => $quantite) {
            $data = ["id_article" => $id];
            $article = new Article();
            $articles[] = [$quantite, $article->getArticleById($data)];
        }

        return $articles;
    }
}
