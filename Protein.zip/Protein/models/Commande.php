<?php

class Commande extends Model
{
    public function __construct()
    {
        parent::__construct();
        $this->table = "Commande";
        require_once(ROOT . "models/ArticleCommande.php");
    }

    public function getAll()
    {
        $this->sql = "SELECT c.*,ac.*, a.*,ac.quantite as quantite_commande, c.prix as prix_commande, a.nom as nom_article
                             from $this->table c JOIN articlecommande ac ON c.id_commande = ac.id_commande 
                             Join article a ON a.id_article = ac.id_article  ";
        return $this->getLines();
    }

    public function getByUtilisateur($data)
    {
        $this->sql = "SELECT c.*,ac.*, a.*,ac.quantite as quantite_commande, c.prix as prix_commande, a.nom as nom_article
                             from $this->table c JOIN articlecommande ac ON c.id_commande = ac.id_commande 
                             Join article a ON a.id_article = ac.id_article WHERE c.id_utilisateur = :id_utilisateur ";
        return $this->getLines($data, false);
    }
    public function ajout($data)
    {

        //ajouter dans la base articlecommande
        $this->sql = "INSERT INTO $this->table (quantite,prix,date_creation, id_utilisateur) values (:quantite,:prix,:date_creation, :id_utilisateur) ";
        return $this->getLines($data, null);
    }
}
