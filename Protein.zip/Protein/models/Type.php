<?php

class Type extends Model
{
    public function __construct()
    {
        parent::__construct();
        $this->table = "Type";
    }

    public function getAll()
    {
        global $oPDO;
        $this->sql = "Select * from $this->table ";
        $stmt = $oPDO->query($this->sql);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }
}
