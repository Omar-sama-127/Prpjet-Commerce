<?php

class ArticleCommande extends Model
{
    public function __construct()
    {
        parent::__construct();
        $this->table = "articlecommande";
    }
    public function ajout($data)
    {
        $this->sql = "INSERT INTO $this->table (id_commande, id_article, quantite) VALUES (:id_commande, :id_article, :quantite) ";
        return $this->getLines($data, null);
    }
}
