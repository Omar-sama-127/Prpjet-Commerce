<div class="container container-fluid m-5 row">
    <div class="row">
        <?php $total = 0 ?>

        <!-- table de l'ensemble des produits -->
        <div class="col-9">




            <table class="table">

                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Image</th>
                        <th scope="col">Nom</th>
                        <th scope="col">Courte description</th>
                        <th scope="col">Prix</th>
                        <th scope="col">Quantite</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $cnt = 1; ?>
                    <?php foreach ($articles as $article) : ?>

                        <?php
                        $quantite = $article[0];
                        $article = $article[1];
                        ?>
                        <form method="POST" action=<?= URI . "paniers/modifier?id_article=" . $article["id_article"] ?>>
                            <tr>
                                <th scope="row"><?= $cnt++; ?></th>
                                <td>
                                    <img height="100px" width="100px" src=<?php
                                                                            if (!empty($article["chemin_images"][0])) {
                                                                                echo URI . $article["chemin_images"][0];
                                                                            } else {
                                                                                echo URI . "public/default.jpg";
                                                                            }

                                                                            ?> class=" row card-img-top" alt="this is a protein powder photo">
                                </td>
                                <td><?= $article["nom"]; ?></td>
                                <td><?= $article["courte_description"]; ?></td>
                                <td><?= $article["prix"]; ?></td>
                                <td><input min=0 max=<?= $article["quantite"] ?> name="quantite" type="number" value=<?= $quantite; ?>></td>
                                <td class="row">

                                    <button type="submit" class="btn btn-warning  col" name="modifierPanier"><i class="bi bi-pencil-square"></i></button>

                                    <div class="col-1"></div>
                                    <a href=<?= URI . "paniers/supprimer?id_article=" . $article["id_article"]; ?> class="btn btn-danger col"><i class="bi bi-trash3-fill"></i></a>

                                </td>
                            </tr>
                        </form>
                    <?php endforeach; ?>

                </tbody>
            </table>
        </div>
        <div class="col-3">
            <div class="col">
                <div class="card">
                    <div class="card-body flex ">
                        <h5 class="card-header text-center">Votre panier</h5>


                        <div>
                            <p class="card-text">Quantite : <?= count($_SESSION["panier"]); ?> </p>
                            <p class="card-text">Total hors taxe : <?php $total = 0;
                                                                    foreach ($articles as $article) {

                                                                        $total +=  $article[1]["prix"] * $_SESSION["panier"][$article[1]["id_article"]];
                                                                    };
                                                                    echo $total; ?> </p>
                            <p class="card-text">Total avec taxe : <?= $total += ($total * 15) / 100 ?> </p>
                        </div>


                        <div class="row flex align-items-center">
                            <form method="post" action=<?= URI . "Commandes/Ajout?prix=" . $total ?>>
                                <input type="submit" name="ajoutCommande" value="Commander" class="btn btn-Success  col m-3 " />
                            </form>

                            <a href=<?= URI . "paniers/vider" ?> class="btn btn-danger col m-3">Vider </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if (isset($_SESSION["ajoutCommande"])) : ?>
        <p class="text-danger"><?= $_SESSION["ajoutCommande"]; ?></p>
        <?php unset($_SESSION["ajoutCommande"]) ?>
    <?php endif ?>

    <?php if (isset($_SESSION["Utilisateur"])) :
    ?>

        <div class="row flex justify-content-center ">
            <!-- class="row flex align-items-center" -->
            <div id="paypal-button-container"> </div>
        </div>

    <?php
    endif;
    ?>

</div>



<script src="https://www.paypal.com/sdk/js?client-id=AfPR6TiXHRHiL3ho58HuXpYQwWciCn8b8iPgqt2D_hsB-Aq7EFuR1ShIaGMnT3vNfgsHoZSUbgMl8b-T&components=buttons"></script>


<script>
    paypal.Buttons({
        style: {
            layout: 'vertical',
            color: 'blue',
            shape: 'rect',
            label: 'paypal'
        },
        // Sets up the transaction when a payment button is clicked
        createOrder: function(data, actions) {
            return actions.order.create({
                purchase_units: [{
                    amount: {
                        value: '0.01'
                    }
                }]
            });
        },
        // Finalize the transaction after payer approval
        onApprove: async (data, actions) => {
            // faire la redirection en javascript
            request.url = "<?= URI . "commandes/commander"; ?>";

            const order = await actions.order.capture();
            console.log(order);
            alert('Transaction completed by ' + order.payer.name.given_name);
        }
    }).render('#paypal-button-container');
</script>