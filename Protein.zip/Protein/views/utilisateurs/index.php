<div class="container  ">
    <div class="row">
        <div class="left-row col-3 my-5 p-0 ">
            <button id="btn-affichage-commande" class="btn btn-primary my-5">
                Vos Commandes
            </button>
            <button id="btn-gestion-profile" class="btn btn-primary my-5">
                Gestion de profil
            </button>

            <?php if ($_SESSION["Utilisateur"]["id_role"] == 2) : ?>
                <button id="btn-gestion-commande" class="btn btn-primary my-5">
                    Gestion des utilisateurs
                </button>
                <button id="btn-gestion-produit" class="btn btn-primary my-5">
                    Gestion de produit
                </button>
            <?php endif; ?>

        </div>
        <div class="col-9" id="content">
            <!-- Content will be dynamically updated here -->
            <div id="gestion-produit" class=" gestion gestion-produit container flex " style="display: none;">
                <!-- table de l'ensemble des produits -->
                <table class="table">

                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Image</th>
                            <th scope="col">Nom</th>
                            <th scope="col">Courte description</th>
                            <th scope="col">Prix</th>
                            <th scope="col">Quantite</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <a href=<?= URI . "articles/ajout"; ?> class="btn btn-indigo-400 col">Ajouter un article </a>
                        </tr>

                        <?php $cnt = 1; ?>
                        <?php foreach ($articles as $article) : ?>
                            <tr>
                                <th scope="row"><?= $cnt++; ?></th>
                                <td>
                                    <img height="100px" width="100px" src=<?php
                                                                            if (!empty($article["chemin_images"][0])) {
                                                                                echo URI . $article["chemin_images"][0];
                                                                            } else {
                                                                                echo URI . "public/default.jpg";
                                                                            }

                                                                            ?> class=" row card-img-top" alt="this is a protein powder photo">
                                </td>
                                <td><?= $article["nom"]; ?></td>
                                <td><?= $article["courte_description"]; ?></td>
                                <td><?= $article["prix"]; ?></td>
                                <td><?= $article["quantite"]; ?></td>
                                <td class="row">
                                    <a href=<?= URI . "articles/modifier?id_article=" . $article["id_article"]; ?> class="btn btn-info col"><i class="bi bi-pencil-square"></i></a>
                                    <div class="col-1"></div>
                                    <a href=<?= URI . "utilisateurs/supprimerArticle?id_article=" . $article["id_article"]; ?> class="btn btn-danger col"><i class="bi bi-trash3-fill"></i></a>

                                </td>
                            </tr>
                        <?php endforeach; ?>

                    </tbody>
                </table>
            </div>

            <div class="gestion gestion-profile" id="gestion-profile" style="display: none;">
                <!-- table de l'ensemble de informations de l'utilisateurs -->
                <form method="POST" action=<?= URI . "utilisateurs/modifierInfo"  ?>>


                    <table class="table">

                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Prenom</th>
                                <th scope="col">email</th>
                                <th scope="col">telephone</th>
                                <th scope="col">date de naissance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <a href=<?= URI . "articles/ajout"; ?> class="btn btn-indigo-400 col">Ajouter un article </a>
                            </tr>
                            <tr>
                                <td></td>
                                <td><input type="text" name="nom" value=<?= $_SESSION["Utilisateur"]["nom"]; ?> placeholder=<?= $_SESSION["Utilisateur"]["nom"]; ?>></td>
                                <td><input type="text" name="prenom" value=<?= $_SESSION["Utilisateur"]["prenom"]; ?> placeholder=<?= $_SESSION["Utilisateur"]["prenom"]; ?>></td>
                                <td><input type="email" name="email" value=<?= $_SESSION["Utilisateur"]["email"]; ?> placeholder=<?= $_SESSION["Utilisateur"]["email"]; ?>></td>
                                <td><input type="number" name="telephone" value=<?= $_SESSION["Utilisateur"]["telephone"]; ?> placeholder=<?= $_SESSION["Utilisateur"]["telephone"]; ?>></td>
                                <td><input type="date" name="date_naissance" value=<?= $_SESSION["Utilisateur"]["date_naissance"]; ?> placeholder=<?= $_SESSION["Utilisateur"]["date_naissance"]; ?>></td>

                            </tr>

                        </tbody>
                    </table>
                    <input class="btn btn-secondary" type="submit" value="Modifier" name="modifierInfo">
                </form>
                <?php if (isset($_SESSION["error-utilisateur-modifierInfo-missingElements"])) : ?>
                    <p class="text-danger"><?= $_SESSION["error-utilisateur-modifierInfo-missingElements"]; ?></p>
                    <?php unset($_SESSION["error-utilisateur-modifierInfo-missingElements"]); ?>
                <?php endif ?>
            </div>

            <div class="gestion gestion-commande" id="gestion-commande" style="display: none;">
                <!-- table de l'ensemble des produits -->
                <table class="table">


                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nom</th>
                            <th scope="col">Prenom</th>
                            <th scope="col">email</th>
                            <th scope="col">telephone</th>
                            <th scope="col">date de naissance</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $cnt = 1; ?>
                        <?php foreach ($utilisateurs as $utilisateur) : ?>
                            <form method="post" action=<?= URI . "utilisateurs/gestionUtilisateur?id_utilisateur=" . $utilisateur["id_utilisateur"] ?>>


                                <tr>
                                    <td><?= $cnt++; ?></td>
                                    <td><input type="text" name="nom" value=<?= $utilisateur["nom"]; ?> placeholder=<?= $utilisateur["nom"]; ?>></td>
                                    <td><input type="text" name="prenom" value=<?= $utilisateur["prenom"]; ?> placeholder=<?= $utilisateur["prenom"]; ?>></td>
                                    <td><input type="email" name="email" value=<?= $utilisateur["email"]; ?> placeholder=<?= $utilisateur["email"]; ?>></td>
                                    <td><input type="number" name="telephone" value=<?= $utilisateur["telephone"]; ?> placeholder=<?= $utilisateur["telephone"]; ?>></td>
                                    <td><input type="date" name="date_naissance" value=<?= $utilisateur["date_naissance"]; ?> placeholder=<?= $utilisateur["date_naissance"]; ?>></td>

                                    <td class="row">
                                        <!-- <input class="btn btn-secondary" type="submit" value="Modifier" name="modifierInfo"> -->
                                        <button type="submit" name="modifier" class="btn btn-info col"><i class="bi bi-pencil-square"></i></button>
                                        <div class="col-1"></div>
                                        <button type="submit" name="supprimer" class="btn btn-danger col"><i class="bi bi-trash3-fill"></i></button>
                                        <!-- <a href=<?= URI . "utilisateurs/supprimerUtilisateur?id_utilisateur=" . $utilisateur["id_utilisateur"]; ?> class="btn btn-danger col"><i class="bi bi-trash3-fill"></i></a> -->

                                    </td>
                                </tr>
                            </form>
                        <?php endforeach; ?>

                    </tbody>
                </table>
            </div>
            <div class="gestion affichage commande" id="affichage-commande" style="display: none;">
                <div class="container container-fluid">
                    <table class="table">

                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Qauntite</th>
                                <th scope="col">Prix</th>
                                <th scope="col">Date de commande </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $cnt = 1;  ?>
                            <?php foreach ($commandes as $commande) : ?>
                                <tr>
                                    <th scope="row"><?= $cnt++; ?></th>

                                    <td><?= $commande["nom_article"]; ?></td>
                                    <td><?= $commande["quantite_commande"]; ?></td>
                                    <td><?= $commande["prix_commande"]; ?></td>
                                    <td><?= $commande["date_creation"]; ?></td>

                                </tr>
                            <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>









<script>
    // Get buttons and sections
    var profileBtn = document.getElementById("btn-gestion-profile");
    var commandeBtn = document.getElementById("btn-gestion-commande");
    var produitBtn = document.getElementById("btn-gestion-produit");
    var affichagecommande = document.getElementById("btn-affichage-commande");
    var contentDiv = document.getElementById("content");


    // Function to hide all gestion sections
    function hideAllGestionSections() {
        var gestionSections = document.querySelectorAll(".gestion");
        gestionSections.forEach(function(section) {
            section.style.display = "none";
        });
    }
    // automatically click the button when the page loads
    window.onload = function() {
        profileBtn.click();
    };

    // Function to hide all forms
    function hideAllForms() {
        var forms = document.querySelectorAll(".form");
        forms.forEach(function(form) {
            form.style.display = "none";
        });
    }

    // Add event listeners to buttons
    profileBtn.addEventListener("click", function() {
        hideAllGestionSections();
        document.getElementById("gestion-profile").style.display = "block";
        hideAllForms(); // Hide all forms when switching gestion sections
    });

    commandeBtn.addEventListener("click", function() {
        hideAllGestionSections();
        document.getElementById("gestion-commande").style.display = "block";
        hideAllForms();
    });

    produitBtn.addEventListener("click", function() {
        hideAllGestionSections();
        document.getElementById("gestion-produit").style.display = "block";
        hideAllForms();
    });
    affichagecommande.addEventListener("click", function() {
        hideAllGestionSections();
        document.getElementById("affichage-commande").style.display = "block";
        hideAllForms();
    });
</script>