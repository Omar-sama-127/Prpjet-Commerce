<div class="row container container-fluid">
    <div class="row"></div>


    <form class="container my-5" method="POST" action="">
        <div class="mb-3">
            <label class="form-label">Email address</label>
            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email">
            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
        </div>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Password</label>
            <input type="password" class="form-control" id="exampleInputPassword1" name="password">
        </div>

        <?php if (isset($_SESSION["error-missingElements-login"])) : ?>
            <p class="text-danger"><?= $_SESSION["error-missingElements-login"]; ?></p>
            <?php unset($_SESSION["error-missingElements-login"]) ?>
        <?php endif ?>
        <?php if (isset($_SESSION["error-pw-login"])) : ?>
            <p class="text-danger"><?= $_SESSION["error-pw-login"]; ?></p>
            <?php unset($_SESSION["error-pw-login"]) ?>
        <?php endif ?>
        <?php if (isset($_SESSION["error-notFound-login"])) : ?>
            <p class="text-danger"><?= $_SESSION["error-notFound-login"]; ?></p>
            <?php unset($_SESSION["error-notFound-login"]) ?>
        <?php endif ?>
        <button type="submit" class="btn btn-primary" name="login" value="login">LogIn</button>
    </form>
    <div class="row">OR</div>
    <?php if (!isset($_SESSION["Utilisateur"])) :  ?>
        <div class="row">
            <a href=<?= URI . "auths/signin" ?>><button class="btn btn-success" style="width: 100px;"> Sign In</button></a>
        </div>
    <?php endif; ?>
</div>