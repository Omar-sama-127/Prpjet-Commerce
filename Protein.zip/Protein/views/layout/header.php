<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">

  <!-- link for bootsterap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <!-- link for font awsome -->
  <script src="https://kit.fontawesome.com/f3e4e24dfe.js" crossorigin="anonymous"></script>


  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>

  <style>
    body {
      margin: 0;
      padding: 0;
      overflow: auto;
    }
  </style>
</head>

<body>


  <!-- nav start -->



  <nav class="navbar navbar-light bg-light sticky-top">
    <div class="container-fluid">
      <a href=<?= URI . "articles/index" ?> class="navbar-brand text-danger fw-bold fs-4"><i class="fa-solid fa-dumbbell fa-beat"> BFit</i></a>
      <div class="dropdown">

        <?php if (isset($_SESSION["Utilisateur"])) : ?>

          <a class="" href=<?= URI . "paniers/index" ?>>
            <button type="button" class="btn btn-primary"><i class="bi bi-cart-fill  ">
                <?php if (isset($_SESSION["panier"])) {
                  echo count($_SESSION["panier"]);
                } else {
                  echo 0;
                } ?>
              </i></button>
          </a>

          <a href=<?= URI . "utilisateurs/index" ?>>
            <button type="button" class="btn btn-info"><i class="bi bi-person-fill"></i> <?= $_SESSION["Utilisateur"]["nom"] ?></button>
          </a>
          <a href=<?= URI . "auths/deconnexion" ?>>
            <button type="button" class="btn btn-danger"><i class="bi bi-box-arrow-right"></i></button>
          </a>



        <?php else : ?>

          <a href=<?= URI . "auths/login" ?>>
            <button type="button" class="btn btn-info">Connecter vous!</button>
          </a>
          <a href=<?= URI . "auths/signin" ?>>
            <button type="button" class="btn btn-danger"> Creez un compte <br> GRATUITEMENT</button>
          </a>


        <?php endif; ?>



      </div>
    </div>
  </nav>


  <nav class="navbar navbar-light bg-light">
    <div class="container-lg ">
      <div class="row nav1 w-100">
        <div class="col-4 ">
          <i class="fa-solid fa-location-dot"> Nous sommes ici!</i>
        </div>
        <div class="col-4">
          <i class="fa-solid fa-phone">Tel : 558-878-7412</i>
        </div>
        <div class="col-4">
          <i class="fa-solid fa-envelope"> Email : email@gmail.com</i>
        </div>
      </div>
    </div>
  </nav>


</body>

</html>