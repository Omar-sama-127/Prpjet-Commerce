<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
<!-- the style file  -->
<!-- <link rel="stylesheet" href="../style.css">
    <title>Document</title>
    <style> -->

<!-- footer {
                  position: fixed;
                  bottom: 0;
                  left: 0;
                  width: 100%;
                  background-color: white;
                  z-index: 3; /* Place the footer above the video container and content */
              }
    </style>
</head>
<body> -->
<!-- foogter start -->
<footer class="footer border-top py-4 ">
  <div class="container-lg">
    <div class="row  text-center">
      <div class="col">
        <i class="fa-brands fa-facebook"></i>
        <i class="fa-solid fa-envelope"></i>
        <i class="fa-brands fa-twitter"></i>
        <i class="fa-brands fa-youtube"></i>
      </div>

    </div>
    <div class="row">
      <div class="col-lg-12">
        <p class="m-0 text-center text-muted"> &copy; Omar Boughram,Abdelrahman Elmach,Abdelrahman Wanhar </p>
      </div>
    </div>

  </div>
</footer>

<!-- bootstrap bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<!-- foogter end -->
<!-- </body>
</html> -->