<style>
    body {
        overflow-y: scroll;
        /* Enable vertical scrolling */
        height: 100vh;
        /* Set the body height to the full viewport height */
    }

    <?php
    include_once(ROOT . "style/utilisateurs.css");
    include_once(ROOT . "style/articles.index.css");
    include_once(ROOT . "style/utilisateurs.index.css");
    // require_once(ROOT . "style/signin.css");

    ?>
</style>



<body class="container-fluid">
    <?php include_once(ROOT . 'views/layout/header.php')   ?>
    <?= $contenu  ?>
    <?php include_once(ROOT . 'views/layout/footer.php')   ?>

</body>

</html>