<style>
    h1 {
        text-align: center;
        font-family: 'Courier New', Courier, monospace;
    }

    /* .table{
        display: flex;
        margin-left: 300px;
    } */
    main form a {
        text-decoration: none;
        color: aliceblue;
    }

    main {
        display: flex;
        justify-content: center;
        /* Horizontally center the content */
        align-items: center;
        /* Vertically center the content */
        width: vh;
        /* Make the main container take up the full viewport height */

    }

    main form {
        width: 1000px;
    }

    /* Style for submit button */
    main form .btn-primary {
        background-color: #007bff;
        border: none;
        color: white;
        padding: 10px 20px;
        border-radius: 10px;
        cursor: pointer;
    }

    /* Style for submit button hover effect */
    main form .btn-primary:hover {
        background-color: #0056b3;
    }
</style>


<h1>Ajouter un produit</h1>
<main>




    <form class="row g-3 m-3 mt-0" method="post" enctype="multipart/form-data">


        <div class="col-12">
            <label>Nom</label>
            <input type="text" class="form-control" name="nom" placeholder="Whey protein">
        </div>
        <div class="col-12">
            <label>Prix</label>
            <input type="text" class="form-control" name="prix" placeholder="20.99">
        </div>

        <div class="col-12">
            <label class="row ms-1">Type</label>

            <!-- repeat this as many times the table has data  -->
            <?php foreach ($types as $type) {
            ?>

                <div class="form-check form-check-inline ms-5">
                    <input class="form-check-input" type="radio" name="id_type" value=<?= $type['id_type'] ?>>
                    <label class="form-check-label" for="inlineRadio1"><?= $type['description'] ?></label>
                </div>

            <?php
            } ?>

        </div>

        <div class="col-12">
            <label>Description</label>
            <input type="text" class="form-control" name="description" placeholder="Premium whey protein...">
        </div>
        <div class="col-12">
            <label>Courte description</label>
            <input type="text" class="form-control" name="courte_description" placeholder="High-quality protein">
        </div>
        <div class="col-12">
            <label>Quantite</label>
            <input type="number" class="form-control" name="quantite" placeholder="100">
        </div>
        <div class="col-12">
            <label>Image</label>
            <input type="file" class="form-control" name="image[]" multiple>
        </div>
        <div>
            <?php if (isset($_SESSION["error-modification-product"])) : ?>
                <p class="text-danger"><?= $_SESSION["error-modification-product"]; ?></p>
            <?php endif;
            unset($_SESSION["error-modification-product"]) ?>
        </div>
        <div>
            <?php if (isset($_SESSION["ajoutArticle"])) : ?>
                <p class="text-danger"><?= $_SESSION["ajoutArticle"]; ?></p>
            <?php endif;
            unset($_SESSION["ajoutArticle"]) ?>
        </div>


        <div class="col-12">
            <button type="submit" class="btn btn-primary" name="ajouter" value="ajouter">Ajouter</button>
        </div>
    </form>
</main>