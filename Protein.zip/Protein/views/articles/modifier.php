<style>
    h1 {
        text-align: center;
        font-family: 'Courier New', Courier, monospace;
    }

    /* .table{
        display: flex;
        margin-left: 300px;
    } */
    main form a {
        text-decoration: none;
        color: aliceblue;
    }

    main {
        display: flex;
        justify-content: center;
        /* Horizontally center the content */
        align-items: center;
        /* Vertically center the content */
        width: vh;
        /* Make the main container take up the full viewport height */

    }

    main form {
        width: 1000px;
    }

    /* Style for submit button */
    main form .btn-primary {
        background-color: #007bff;
        border: none;
        color: white;
        padding: 10px 20px;
        border-radius: 10px;
        cursor: pointer;
    }

    /* Style for submit button hover effect */
    main form .btn-primary:hover {
        background-color: #0056b3;
    }
</style>


<h1>Modifier un produit</h1>
<main class="row mx-5  ">




    <form class="row g-3 m-3 mt-0" method="post" enctype="multipart/form-data">



        <div class="col-12">
            <label>Nom</label>
            <input type="text" class="form-control" name="nom" placeholder=<?= $articles["nom"]; ?>>
        </div>
        <div class="col-12">
            <label>Prix</label>
            <input type="number" class="form-control" name="prix" placeholder=<?= $articles["prix"]; ?>>
        </div>

        <div class="col-12">
            <label class="row ms-1">Type</label>

            <!-- repeat this as many times the table has data  -->
            <?php foreach ($types as $type) {
            ?>

                <div class="form-check form-check-inline ms-5">
                    <input class="form-check-input" type="radio" name="id_type" value=<?= $type['id_type'] ?>>
                    <label class="form-check-label" for="inlineRadio1"><?= $type['description'] ?></label>
                </div>

            <?php
            } ?>

        </div>

        <div class="col-12">
            <label>Description</label>
            <input type="text" class="form-control" name="description" placeholder=<?= $articles["description"]; ?>>
        </div>
        <div class="col-12">
            <label>Courte description</label>
            <input type="text" class="form-control" name="courte_description" placeholder=<?= $articles["courte_description"]; ?>>
        </div>
        <div class="col-12">
            <label>Quantite</label>
            <input type="number" class="form-control" name="quantite" placeholder=<?= $articles["quantite"]; ?>>
        </div>
        <div class="col-12">
            <label>Image</label>
            <input type="file" class="form-control" name="image[]" multiple>
        </div>
        <?php if (isset($_SESSION["error-modification-product"])) : ?>
            <p class="text-danger"><?= $_SESSION["error-modification-product"]; ?></p>
        <?php endif ?>
        <div class="col-12">
            <button type="submit" class="btn btn-primary" name="modifier" value="modifier">Modifier</button>
        </div>
    </form>

    <!-- a list of the images related to the article -->

    <?php if (empty($imagePath)) : ?>
        <fom methode="post" action=<?= URI . "images/deleteByChemin?chemin_image=" . isset($imagePath)  ?>>


            <div class="row row-cols-1 row-cols-md-3 g-4 m-5">
                <?php foreach ($imagePaths  as $imagePath) : ?>
                    <?php if (!empty($imagePath)) : ?>
                        <div class="row m-1 text-align-center">
                            <div class="card">
                                <div class="card-image">
                                    <img height="200px" width="50px" src=<?php
                                                                            if (!empty($imagePath)) {
                                                                                echo URI . $imagePath;
                                                                            }

                                                                            ?> class="card-img-top" alt="...">
                                </div>

                                <div class="card-body">
                                    <a href=<?= URI . "images/deleteByChemin?chemin_image=" . $imagePath  ?>>
                                        <button class="btn btn-danger" name="supprimer-image" value="Supprimer">Supprimer</button>
                                    </a>

                                </div>
                            </div>

                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </fom>
    <?php endif; ?>
    <div>
        <a href=<?= URI . "utilisateurs/index"  ?>>
            <button type="button" class="btn btn-secondary">Retour au profil</button>
        </a>

    </div>

</main>