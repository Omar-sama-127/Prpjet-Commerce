<?php  // include_once(ROOT."views/layout/header.php")  

?>
<div class="container articles-index">
    <div class="row">
        <?php
        foreach ($articles as $article) {

        ?>
            <div class="card row m-3" style="width: 18rem;">
                <img src=<?php
                            //ajouter une image par defaut pour chaque type :)
                            if (!empty($article["chemin_images"][0])) {
                                echo URI . $article["chemin_images"][0];
                            } else {
                                echo URI . "public/default.jpg";
                            }

                            ?> class=" row card-img-top" alt="this is a protein powder photo">
                <div class="row card-body">
                    <h5 class=" m-0 p-0 card-title"><?= $article["nom"]; ?></h5>
                    <p class=" m-0 p-0 card-text"><?= $article["courte_description"]; ?></p>
                    <div class="row flex align-items-center  ">
                        <a href=<?= URI . "paniers/ajouter?id_article=" . $article["id_article"]; ?> class="col p-2 btn btn-primary">Ajouter au panier</a>

                    </div>
                </div>
            </div>
        <?php
        }
        ?>

    </div>


</div>