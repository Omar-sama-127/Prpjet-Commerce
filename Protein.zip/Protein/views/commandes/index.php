<div class="container container-fluid">
    <table class="table">

        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nom</th>
                <th scope="col">Qauntite</th>
                <th scope="col">Prix</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $cnt = 1;  ?>
            <?php foreach ($commandes as $commande) : ?>
                <tr>
                    <th scope="row"><?= $cnt++; ?></th>

                    <td><?= $commande["nom_article"]; ?></td>
                    <td><?= $commande["quantite_commande"]; ?></td>
                    <td><?= $commande["prix_commande"]; ?></td>
                    <td><?= $commande["date_creation"]; ?></td>

                </tr>
            <?php endforeach; ?>

        </tbody>
    </table>
</div>