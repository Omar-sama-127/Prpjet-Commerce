<?php
require_once(ROOT . 'app/configs/DataBase.php');


abstract class Model
{
    protected $sql;
    protected $table;

    public function __construct()
    {
    }

    public function getLines($params = [], $estuneligne = false)
    {
        global $oPDO;
        $stmt = $oPDO->prepare($this->sql);

        foreach ($params as $paramKey => $paramValue) {
            $stmt->bindValue(":" . trim($paramKey), trim($paramValue));
        }


        $result = $stmt->execute();
        //insert, update, delete
        if ($estuneligne === null) {
            return $result;
        }

        //select 
        return $estuneligne ?
            $stmt->fetch(PDO::FETCH_ASSOC) : //we can use obj instead of the assoc array 
            $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
