<?php

abstract class Controller
{


    public function __construct()
    {
    }

    public function loadModel(string $model)
    {
        //we search the file corrsponding to the desired model
        require_once(ROOT . 'models/' . $model . '.php');

        //create an instance 
        $this->$model = new $model();
    }

    public function render(string $fichier, array $data = [])
    {
        //recuperer les donnes et les extraire sous forme de variables 
        extract($data);
        ob_start();

        // Crée le chemin et inclut le fichier de vue
        require_once(ROOT . 'views/' . strtolower(get_class($this)) . '/' . $fichier . '.php');


        $contenu = ob_get_clean();
        require_once(ROOT . 'views/layout/default.php');
    }


    public function isValid($data)
    {
        foreach ($data as $element) {
            if (empty($element)) {
                return false;
            }
        }
        return true;
    }
}
