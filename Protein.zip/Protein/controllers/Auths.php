<?php

class Auths extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }


    public function login()
    {
        $this->loadModel('Utilisateur');

        if (isset($_POST["login"])) {

            if ($this->isValid($_POST)) {

                $email = $_POST["email"];
                $mot_de_passe = $_POST["password"];
                $data = ["email" => $email];
                unset($_POST["mot_de_passe"], $_POST["login"]);

                $utilisateur = new Utilisateur();
                $utilisateur = $utilisateur->findByEmail($data);

                if ($utilisateur) {
                    if (password_verify($mot_de_passe, $utilisateur["mot_de_passe"])) {
                        unset($utilisateur["mot_de_passe"]);
                        $_SESSION["Utilisateur"] = $utilisateur;

                        header("Location: " . URI . "articles/index");
                    } else {
                        $_SESSION["error-pw-login"] = "mot de passe est faux";
                        //exit(); // Ensure that script execution stops after the redirect
                    }
                } else {
                    $_SESSION["error-notFound-login"] = "Utilisateur non trouve!";
                    //exit(); // Ensure that script execution stops after the redirect
                }
            } else {
                $_SESSION["error-missingElements-login"] = "Please fill all the inputs!";
                //exit(); // Ensure that script execution stops after the redirect
            }
        }

        $this->render('login');
    }


    public function signin()
    {
        //load the model
        $this->loadModel('Utilisateur');

        if (isset($_POST["sign_in"])) {

            if ($this->isValid($_POST)) {
                if ($_POST["mot_de_passe"] === $_POST["confirm_mdp"]) {
                    var_dump($_POST);
                    //unset() pour supprimer des elem du tab
                    unset($_POST["sign_in"], $_POST["confirm_mdp"]);
                    $_POST["mot_de_passe"] = password_hash($_POST["mot_de_passe"], PASSWORD_DEFAULT);
                    $_POST["id_role"] = 2;
                    try {
                        $Utilisateur = new Utilisateur();
                        $Utilisateur->ajouter($_POST);
                        header("Location: " . URI . "auths/login");
                        exit();
                    } catch (PDOException $e) {
                        if ($e->getCode() == '23000' && strpos($e->getMessage(), 'Duplicate entry') !== false) {
                            $_SESSION["error-emailDuplicate"] = "Email already exists.";
                        } else {
                            // Handle other PDOExceptions or unexpected errors
                            $_SESSION["error-unknown"] = $e->getMessage();
                        }
                    }
                }
            } else {
                $_SESSION["error-missingElements"] = "Please fill all the inputs and make sure the passwords are matching!";
                //exit(); // Ensure that script execution stops after the redirect
            }
        }
        $this->render("signin");
    }

    public function deconnexion()
    {
        session_destroy();
        header("Location: " . URI . "articles/index");
    }
}
