<?php

class Commandes extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->loadModel("Commande");
        $this->loadModel("Article");
        $this->loadModel("ArticleCommande");
    }

    public function index()
    {

        $data = ["id_utilisateur" => (int)$_SESSION["Utilisateur"]["id_utilisateur"]];
        $commandes = new Commande();
        $commandes = $commandes->getByUtilisateur($data);

        foreach ($commandes as $item) {
            var_dump(compact("item"));
            echo "<br><br>";
        }


        //   $this->render('index', compact("commandes"));
    }


    public function Ajout()
    {

        if (isset($_POST["ajoutCommande"])) {
            $quantite = 0;
            foreach ($_SESSION["panier"] as $id => $quantite) {

                $quantite += $quantite;
            }


            $id_utilisateur = $_SESSION["Utilisateur"]["id_utilisateur"];
            $prix = floatval($_GET["prix"]);
            $date_creation = date('Y-m-d');
            $data = ["id_utilisateur" => (int)$id_utilisateur, "quantite" => (int)$quantite, "prix" => $prix, "date_creation" => $date_creation];

            var_dump($data);
            var_dump($_GET);
            //on ajoute la commande
            $newCommande = new Commande();
            $newCommande->Ajout($data);

            global $oPDO;
            $id_commande = $oPDO->lastInsertId();

            //on ajoute les donnees dans la table articlecommande
            foreach ($_SESSION["panier"] as $id => $quantite) {

                $data = ["id_commande" => $id_commande, "id_article" => $id, "quantite" => $quantite];
                var_dump($data);
                $articlecommande = new ArticleCommande();
                $articlecommande->ajout($data);
            }
        }
        $_SESSION["ajoutCommande"] = "Commade faite avec success";

        //on redirige lutilisateur vers le panier

        // Check if the HTTP_REFERER is set and not empty
        if (isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER'])) {
            // Redirect the user back to the previous page
            header("Location: " . $_SERVER['HTTP_REFERER']);
            exit;
        } else {
            // If HTTP_REFERER is not set or empty, redirect to a default page
            header("Location: default-page.php");
            exit;
        }
    }
}
