<?php
class Images extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function deleteByChemin()
    {
        $chemin_image = $_GET["chemin_image"];
        $data = ["chemin_image" => $chemin_image];
        $this->loadModel('image');
        $image = new Image();
        $image->deleteByChemin($data);

        if (isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER'])) {
            // Redirect the user back to the previous page
            header("Location: " . $_SERVER['HTTP_REFERER']);
            exit;
        } else {
            // If HTTP_REFERER is not set or empty, redirect to a default page
            header("Location: " . URI . "utilisateurs/index");
            exit;
        }
    }
}
