<?php 

class Main extends Controller{

public function index (){
    echo   "c'EST  le main de mon site web";
}

}


?>