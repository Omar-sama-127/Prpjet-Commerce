<?php

class Utilisateurs extends Controller
{

    public function __construct()
    {
        parent::__construct();
        //on instancie le model article
        $this->loadModel('Article');
        $this->loadModel('Image');
        $this->loadModel("Utilisateur");
        $this->loadModel("Commande");
    }


    public function index()
    {


        //recuperer tous les utilisateurs
        $utilisateurs = new Utilisateur();
        $utilisateurs = $utilisateurs->getAllUsers();

        //retrive all the protein articles 
        $articles = new Article();
        $articles = $articles->getAll();

        //recuperer les commandes
        $data = ["id_utilisateur" => (int)$_SESSION["Utilisateur"]["id_utilisateur"]];
        $commandes = new Commande();
        $commandes = $commandes->getByUtilisateur($data);

        foreach ($articles as &$article) {
            $article["chemin_images"] = explode(",", $article["chemin_images"]);
        }

        // On envoie les données à la vue index
        $this->render('index', compact("articles", "utilisateurs", "commandes"));
    }


    public function modifierInfo()
    {
        if (isset($_POST["modifierInfo"])) {
            if ($this->isValid($_POST)) {
                unset($_POST["modifierInfo"]);
                $_POST["id_utilisateur"] = $_SESSION["Utilisateur"]["id_utilisateur"];
                //load the models
                $this->loadModel("utilisateur");
                $utilisateur = new Utilisateur();
                $utilisateur->modifierById($_POST);
                $this->index();
            } else {
                $_SESSION["error-utilisateur-modifierInfo-missingElements"] = "Please fill all the inputs";
                $this->index();
            }
        }
    }

    public function gestionUtilisateur()
    {
        if (isset($_POST["modifier"])) {
            unset($_POST["modifier"]);

            $_POST["id_utilisateur"] = (int) $_GET["id_utilisateur"];
            $utilisateur = new Utilisateur();
            $utilisateur->modifierById($_POST);

            $this->index();
        }
        if (isset($_POST["supprimer"])) {

            if (isset($_GET["id_utilisateur"])) {
                $data = ["id_utilisateur" => ((int)$_GET["id_utilisateur"])];

                $utilisateur = new Utilisateur();
                $utilisateur->supprimerUtilisateur($data);

                $this->index();
            }
        }
    }



    public function supprimerArticle()
    {
        require_once(ROOT . 'controllers/Articles.php');
        if (isset($_GET["id_article"])) {

            $id_article = $_GET["id_article"];

            $articles = new Articles();
            $articles->supprimerById($id_article);
        }
        $this->index();
    }
}
