<?php
class Paniers extends Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->loadModel("panier");
    }

    public function index()
    {
        $panier = new Panier();
        $articles = $panier->getAllPanier();
        foreach ($articles as &$article) {
            $article[1]["chemin_images"] = explode(",", $article[1]["chemin_images"]);
        }
        //var_dump($articles);
        $this->render("index", compact("articles"));
    }

    public function ajouter()
    {
        if (isset($_GET["id_article"])) {
            if (is_numeric((int)$_GET["id_article"])) {
                $id_article = (int) $_GET["id_article"];
                $panier = new Panier();
                $panier = $panier->ajouter($id_article, 1);
                if (isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER'])) {
                    // Redirect the user back to the previous page
                    header("Location: " . $_SERVER['HTTP_REFERER']);
                    exit;
                } else {
                    // If HTTP_REFERER is not set or empty, redirect to a default page
                    echo "Brother i am lost and so are you :(";
                }
            } else {
                echo "id_article exits but it is not a number. ";
                http_response_code(404);
            }
        } else {
            echo "error 404 \. there is nth for you in this page :(. There is no id_article. ";
            http_response_code(404);
        }
    }

    public function supprimer()
    {
        if (isset($_GET["id_article"])) {
            if (is_numeric((int)$_GET["id_article"])) {
                $id_article = (int) $_GET["id_article"];
                $panier = new Panier();
                $panier = $panier->supprimer($id_article);

                // Check if the HTTP_REFERER is set and not empty
                if (isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER'])) {
                    // Redirect the user back to the previous page
                    header("Location: " . $_SERVER['HTTP_REFERER']);
                    exit;
                } else {
                    // If HTTP_REFERER is not set or empty, redirect to a default page
                    header("Location: default-page.php");
                    exit;
                }
            }
        } else {
            echo "error 404. There is nth for you in this page :(. There is no id_article. ";
            http_response_code(404);
        }
    }


    public function modifier()
    {
        if (isset($_POST["modifierPanier"])) {
            if (isset($_GET["id_article"])) {
                if (is_numeric((int)$_GET["id_article"])) {
                    $id_article = (int) $_GET["id_article"];
                    $quantite = $_POST["quantite"];
                    $panier = new Panier();
                    $panier = $panier->ajouter($id_article, $quantite);

                    // Check if the HTTP_REFERER is set and not empty
                    if (isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER'])) {
                        // Redirect the user back to the previous page
                        header("Location: " . $_SERVER['HTTP_REFERER']);
                        exit;
                    } else {
                        // If HTTP_REFERER is not set or empty, redirect to a default page
                        header("Location: default-page.php");
                        exit;
                    }
                }
            } else {
                echo "error 404. There is nth for you in this page :(. There is no id_article. ";
                http_response_code(404);
            }
        } else {
            echo "T'as rien a foutre ici ;)";
            http_response_code(404);
        }
    }

    public function vider()
    {
        unset($_SESSION["panier"]);
        $this->index();
    }
}
