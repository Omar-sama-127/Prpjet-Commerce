<?php


class Articles extends Controller
{


    public function index()
    {
        //on instancie le model article
        $this->loadModel('Article');
        $this->loadModel('Image');

        //retrive all the protein articles 
        $articles = $this->Article->getAll();



        foreach ($articles as &$article) {
            $article["chemin_images"] = explode(",", $article["chemin_images"]);
        }
        // On envoie les données à la vue index
        $this->render('index', compact("articles"));
    }


    //ajouter un article
    public function ajout()
    {
        $this->loadModel('Article');
        $this->loadModel('Image');

        //we need to retrieve the data from the type table (ptotein - acide amine ....)
        $this->loadModel('Type');
        $types = $this->Type->getAll();

        if (isset($_POST["ajouter"])) {
            if ($this->isValid($_POST)) {
                //on a pas besoin du boutton ni de l'image
                unset($_POST["ajouter"]);

                // Cast the 'type' field to an integer
                $_POST["id_type"] = (int) $_POST["id_type"];
                $_POST["quantite"] = (int) $_POST["quantite"];

                $article = new Article();
                $article->ajout($_POST);

                //ON AJoute le ou les images correspondant au produit ajoute
                //on utilse la methode lastInsertedId()
                global $oPDO;
                $id_article = $oPDO->lastInsertId();

                $this->upload($id_article);
                $_SESSION["ajoutArticle"] = "Article added !";
            } else {
                $_SESSION["error-modification-product"] = "Veuillez remplir tous les champs";
            }
        }
        $this->render('ajout', compact('types'));
    }


    public function upload($id_article)
    {
        if (isset($_FILES["image"])) {
            $imgExt = ["png", "jpg", "jpeg", "webg", "svg"];

            //to add multiple photos
            foreach ($_FILES["image"]["name"] as $key => $value) {

                foreach ($imgExt as $ext) {
                    if (pathinfo($value)["extension"] === $ext) {

                        //on aura besoin du chemin du fichier uploaded (ou il est stocler temporairement)
                        $from = $_FILES["image"]["tmp_name"][$key];

                        //destination + le nom qu'on donnera a l'image uploader
                        $name = $_FILES["image"]["name"][$key];
                        $to = "public/images/" . $name;

                        if (move_uploaded_file($from, ROOT . $to)) {
                            $this->loadModel("image");
                            $image = new Image();
                            $data = ["id_article" => $id_article, "chemin_image" => $to];
                            $image->ajouter($data);
                        }
                    }
                }
            }
        }
    }

    public function modifier()
    {
        if (isset($_GET["id_article"])) {
            $id_article = $_GET["id_article"];
            $this->loadModel("article");
            $article = new Article();
            $data = ["id_article" => $id_article];
            if ($article->getArticleById($data)) {




                $this->loadModel("type");

                $articles = new Article();
                $data = ["id_article" => $id_article];
                $articles = $articles->getArticleById($data);

                $types = new Type();
                $types = $types->getAll();


                //now we check the informations and submit the changes
                if (isset($_POST["modifier"])) {
                    if ($this->isValid($_POST)) {
                        //on a pas besoin du boutton ni de l'image
                        unset($_POST["modifier"]);

                        // Cast the 'type' field to an integer
                        $_POST["id_type"] = (int) $_POST["id_type"];
                        $_POST["quantite"] = (int) $_POST["quantite"];
                        $_POST["id_article"] = $id_article;

                        $article = new Article();
                        $article->modiferById($_POST);

                        $this->upload($id_article);

                        header("location:" . URI . "utilisateurs    /index");
                    } else {
                        $_SESSION["error-modification-product"] = "Veuillez remplir tous les champs";
                    }
                }

                // if (isset($_POST["supprimer-image"])) {
                //     $chemin_image = $_GET["chemin_image"];
                //     $data = ["chemin_image" => $chemin_image];
                //     $image = new Image();
                //     $image->deleteByChemin($data);
                // }

                //var_dump($articles["chemin_images"]);
                $imagePaths  = explode(",", $articles["chemin_images"]);
                var_dump($imagePaths);
                //var_dump(compact($images));

                $this->render("modifier", compact("articles", "types", "imagePaths"));
            } else {
                echo "cet article n'existe pas";
                http_response_code(404);
            }
        } else {
            echo "cette page n'existe pas";
            http_response_code(404);
        }
    }

    public function supprimerById($id_article)
    {
        $id_article = (int) $id_article;
        $this->loadModel("article");
        $article = new Article();
        $data = ["id_article" => $id_article];

        if ($article->getArticleById($data)) {

            $article = $article->supprimerById($data);

            //ON SUPPRIMER LES IMAGES ASSOCIES AUX produits
            $this->loadModel("image");
            $image = new Image();
            $image->supprimerByIdArticle($data);

            //$this->render("modifier", compact("articles", "types", "imagePaths"));
        } else {
            echo "cet article n'existe pas";
            http_response_code(404);
        }
    }
}
