<div class="row">

    <div class="row choix ">
        <div class="col">
            <button id="btn-ajouter-produit" class="btn btn-primary my-5">
                Ajouter un produit
            </button>
        </div>
        <div class="col">
            <button id="btn-modifier-produit" class="btn btn-primary my-5">
                Modifier un produit
            </button>
        </div>
        <div class="col">
            <button id="btn-suprimer-produit" class="btn btn-primary my-5">
                Suprimer un produit
            </button>
        </div>
    </div>

    <div id="content-form" class="row">
        <div id="form-ajouter-produit" class="row form-ajouter">
            <h1>Ajouter un produit</h1>
            <main>
                <form class="row g-3 m-3 mt-0" method="post" enctype="multipart/form-data">
                    <div class="col-12">
                        <label>Nom</label>
                        <input type="text" class="form-control" name="nom" placeholder="Whey protein" />
                    </div>
                    <div class="col-12">
                        <label>Prix</label>
                        <input type="number" class="form-control" name="prix" placeholder="20.99" />
                    </div>

                    <div class="col-12">
                        <label class="row ms-1">Type</label>

                        <!-- repeat this as many times the table has data  -->
                        <?php foreach ($types as $type) : ?>
                            <div class="form-check form-check-inline ms-5">
                                <input class="form-check-input" type="radio" name="id_type" value="<?= $type['id_type'] ?>" />
                                <label class="form-check-label" for="inlineRadio1"><?= $type['description'] ?></label>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="col-12">
                        <label>Description</label>
                        <input type="text" class="form-control" name="description" placeholder="Premium whey protein..." />
                    </div>
                    <div class="col-12">
                        <label>Courte description</label>
                        <input type="text" class="form-control" name="courte_description" placeholder="High-quality protein" />
                    </div>
                    <div class="col-12">
                        <label>Quantite</label>
                        <input type="number" class="form-control" name="quantite" placeholder="100" />
                    </div>
                    <div class="col-12">
                        <label>Image</label>
                        <input type="file" class="form-control" name="image" />
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-primary" name="ajouter">Ajouter</button>
                    </div>
                </form>
            </main>
        </div>
        <div id="form-modifier-produit" class="row form form-modifier" style="display:none">
            <h1>Modifier un produit</h1>
            <main>
                <form class="row g-3 m-3 mt-0" method="post" enctype="multipart/form-data">
                    <div class="col-12">
                        <label>Nom</label>
                        <input type="text" class="form-control" name="nom" placeholder="Whey protein" />
                    </div>
                    <div class="col-12">
                        <label>Prix</label>
                        <input type="number" class="form-control" name="prix" placeholder="20.99" />
                    </div>

                    <div class="col-12">
                        <label class="row ms-1">Type</label>

                        <!-- repeat this as many times the table has data  -->
                        <?php foreach ($types as $type) : ?>
                            <div class="form-check form-check-inline ms-5">
                                <input class="form-check-input" type="radio" name="type" value="<?= $type['id_type'] ?>" />
                                <label class="form-check-label" for="inlineRadio1"><?= $type['description'] ?></label>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="col-12">
                        <label>Description</label>
                        <input type="text" class="form-control" name="description" placeholder="Premium whey protein..." />
                    </div>
                    <div class="col-12">
                        <label>Courte description</label>
                        <input type="text" class="form-control" name="courte_description" placeholder="High-quality protein" />
                    </div>
                    <div class="col-12">
                        <label>Quantite</label>
                        <input type="number" class="form-control" name="quantite" placeholder="100" />
                    </div>
                    <div class="col-12">
                        <label>Image</label>
                        <input type="file" class="form-control" name="image" />
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">Ajouter</button>
                    </div>
                </form>
            </main>
        </div>
        <div id="form-suprimer-produit" class="row form form-suprimer" style="display:none">
            <h1>Suprimer un produit</h1>
            <main>
                <form class="row g-3 m-3 mt-0" method="post" enctype="multipart/form-data">
                    <div class="col-12">
                        <label>Nom</label>
                        <input type="text" class="form-control" name="nom" placeholder="Whey protein" />
                    </div>
                    <div class="col-12">
                        <label>Prix</label>
                        <input type="number" class="form-control" name="prix" placeholder="20.99" />
                    </div>

                    <div class="col-12">
                        <label class="row ms-1">Type</label>

                        <!-- repeat this as many times the table has data  -->
                        <?php foreach ($types as $type) : ?>
                            <div class="form-check form-check-inline ms-5">
                                <input class="form-check-input" type="radio" name="type" value="<?= $type['id_type'] ?>" />
                                <label class="form-check-label" for="inlineRadio1"><?= $type['description'] ?></label>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="col-12">
                        <label>Description</label>
                        <input type="text" class="form-control" name="description" placeholder="Premium whey protein..." />
                    </div>
                    <div class="col-12">
                        <label>Courte description</label>
                        <input type="text" class="form-control" name="courte_description" placeholder="High-quality protein" />
                    </div>
                    <div class="col-12">
                        <label>Quantite</label>
                        <input type="number" class="form-control" name="quantite" placeholder="100" />
                    </div>
                    <div class="col-12">
                        <label>Image</label>
                        <input type="file" class="form-control" name="image" />
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">Ajouter</button>
                    </div>
                </form>
            </main>
        </div>

    </div>
</div>


<script>
    document.getElementById("btn-ajouter-produit").addEventListener("click", function(e) {
        hideAllForms();
        document.getElementById("form-ajouter-produit").style.display = "flex";
    });

    document.getElementById("btn-modifier-produit").addEventListener("click", function() {
        hideAllForms();
        document.getElementById("form-ajouter-produit").style.display = "none";
        document.getElementById("form-modifier-produit").style.display = "flex";
    });

    document.getElementById("btn-suprimer-produit").addEventListener("click", function() {
        hideAllForms();
        document.getElementById("form-ajouter-produit").style.display = "none";
        document.getElementById("form-suprimer-produit").style.display = "flex";
    });
</script>